self.onmessage = async (e) => {
    try {
        const { id, data, w, h } = e.data;
        var blob = new Blob([data]);
        const bmp = await createImageBitmap(blob, {
            resizeWidth: w,
            resizeHeight: h,
            resizeQuality: 'high'
        });
        const canvas = new OffscreenCanvas(w, h);
        const ctx = canvas.getContext("2d");
        ctx.clearRect(0, 0, w, h);
        ctx.drawImage(bmp, 0, 0);
        bmp.close();

        const imgData = ctx.getImageData(0, 0, w, h);
        const rawBuffer = imgData.data.buffer;
        self.postMessage(
            {
                kind: "result",
                id: id,
                buffer: rawBuffer,
            },
            [rawBuffer]
        );
    } catch (err) {
        self.postMessage({
            kind: "error",
            id: id,
            message: err?.message ?? String(err),
        });
    }
};
